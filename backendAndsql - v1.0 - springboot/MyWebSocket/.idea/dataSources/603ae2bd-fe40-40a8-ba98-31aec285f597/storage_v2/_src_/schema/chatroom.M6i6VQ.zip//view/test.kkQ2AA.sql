create view test as
select `chatroom`.`users`.`id`               AS `id`,
       `chatroom`.`users`.`username`         AS `username`,
       `chatroom`.`users`.`password`         AS `password`,
       `chatroom`.`users`.`icon`             AS `icon`,
       `chatroom`.`users`.`qrcode`           AS `qrcode`,
       `chatroom`.`users`.`cid`              AS `cid`,
       `chatroom`.`users`.`online`           AS `online`,
       `chatroom`.`users`.`introduction`     AS `introduction`,
       `chatroom`.`users`.`background_image` AS `background_image`
from `chatroom`.`users`
where (`chatroom`.`users`.`id` = 1);

